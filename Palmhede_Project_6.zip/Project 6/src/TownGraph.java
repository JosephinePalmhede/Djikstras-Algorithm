import java.util.ArrayList;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TownGraph implements GraphInterface<Town, Road> {
	private Map<String, Town> towns;
	private HashSet<Road> roadsSet;
	private HashSet<Town> townsSet;
	private int edgeCount;
	private int totalDistance;
	
	private Set<Town> settledNodes;
	private Set<Town> unSettledNodes;
	private Map<Town, Town> predecessors;
	private Map<Town, Integer> distance;
	
	public TownGraph() {
		towns = new HashMap<String, Town>();
		edgeCount = 0;
		roadsSet = new HashSet<Road>();
		townsSet = new HashSet<Town>();
	}
	
	/**
     * Returns an edge connecting source vertex to target vertex if such
     * vertices and such edge exist in this graph. Otherwise returns
     * null. If any of the specified vertices is null
     * returns null
     *
     * In undirected graphs, the returned edge may have its source and target
     * vertices in the opposite order.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return an edge connecting source vertex to target vertex.
     */
	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		//System.out.println("get edge");
		Road edge;
		if ((sourceVertex != null) && (destinationVertex != null)) { //if the towns are valid
			if (this.containsEdge(sourceVertex, destinationVertex)) {  //if this graph contains a road connecting the towns
				//System.out.println("it found the edge");
				LinkedList<Road> roads = sourceVertex.getRoadList(); //get a list of roads connected to the source town (the road WILL be on this list)
				for (int j = 0; j < roads.size(); j++) { //go through the list..
					if ((roads.get(j).getDestination().equals(destinationVertex)) || (roads.get(j).getSource().equals(destinationVertex))) { //if the road's source or destination equals the destination vertex..
						if (roads.get(j) == null) System.out.println("why");
						edge = new Road(roads.get(j)); //get that road
						return edge;
					}
				}			
			}
		}
		return null;
	}
	
	public Town getTown(String name) {
		//System.out.println("getTown");
		if (towns.containsKey(name)) return towns.get(name);
		else return null;
	}
	
	 /**
     * Creates a new edge in this graph, going from the source vertex to the
     * target vertex, and returns the created edge. 
     * 
     * The source and target vertices must already be contained in this
     * graph. If they are not found in graph IllegalArgumentException is
     * thrown.
     *
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description for edge
     *
     * @return The newly created edge if added to the graph, otherwise null.
     *
     * @throws IllegalArgumentException if source or target vertices are not
     * found in the graph.
     * @throws NullPointerException if any of the specified vertices is null.
     */
	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		//System.out.println("add edge");
		Road road = null;
		if ((sourceVertex != null) && (destinationVertex != null)) {
			sourceVertex.connect(destinationVertex, weight, description);
			//System.out.println(sourceVertex.getName() + " neighbor list");
			//System.out.println(sourceVertex.getNeighborList());
			//System.out.println(destinationVertex.getName() + " neighbor list");
			//System.out.println(destinationVertex.getNeighborList());
			edgeCount++;
			road = new Road(sourceVertex, destinationVertex, weight, description);
			roadsSet.add(road);
		}
		return road;
	}

	/**
     * Adds the specified vertex to this graph if not already present. More
     * formally, adds the specified vertex, v, to this graph if
     * this graph contains no vertex u such that
     * u.equals(v). If this graph already contains such vertex, the call
     * leaves this graph unchanged and returns false. In combination
     * with the restriction on constructors, this ensures that graphs never
     * contain duplicate vertices.
     *
     * @param v vertex to be added to this graph.
     *
     * @return true if this graph did not already contain the specified
     * vertex.
     *
     * @throws NullPointerException if the specified vertex is null.
     */
	@Override
	public boolean addVertex(Town v) {
		//System.out.println("add vertex");
		Town addOutcome = null;
		if (!townsSet.contains(v) && !towns.containsKey(v.getName())) {
			addOutcome = towns.put(v.getName(), v);
			townsSet.add(v);
			//addOutcome = v;
		}
		return addOutcome == null;
	}

	/**
     * Returns true if and only if this graph contains an edge going
     * from the source vertex to the target vertex. In undirected graphs the
     * same result is obtained when source and target are inverted. If any of
     * the specified vertices does not exist in the graph, or if is
     * null, returns false.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return true if this graph contains the specified edge.
     */
	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		//System.out.println("contains edge");
		boolean found = false;
		
		if((sourceVertex != null) && (destinationVertex != null) && (edgeCount > 0)) {  //if the source and destination are valid...
			LinkedList<Town> neighborList = sourceVertex.getNeighborList();		//get the list of source town's neighbors
				for (int i = 0; i < neighborList.size(); i++) {				    //iterate through them
					if (destinationVertex.equals(neighborList.get(i))) found = true; //if the source town has the destination vertex as a neighbor, the road exists.
					
				}
		}
		return found;
	}

	/**
     * Returns true if this graph contains the specified vertex. More
     * formally, returns true if and only if this graph contains a
     * vertex u such that u.equals(v). If the
     * specified vertex is null returns false.
     *
     * @param v vertex whose presence in this graph is to be tested.
     *
     * @return true if this graph contains the specified vertex.
     */
	@Override
	public boolean containsVertex(Town v) {
		//System.out.println("contains vertex");
		boolean found = false;
		if (v != null) {
			found = ((towns.containsValue(v)) || (towns.containsKey(v.getName())));
		}
		return found;
	}

	/**
     * Returns a set of the edges contained in this graph. The set is backed by
     * the graph, so changes to the graph are reflected in the set. If the graph
     * is modified while an iteration over the set is in progress, the results
     * of the iteration are undefined.
     *
     *
     * @return a set of the edges contained in this graph.
     */
	@Override
	public HashSet<Road> edgeSet() {
		//System.out.println("edgeSet");
		return roadsSet;
	}

	/**
     * Returns a set of all edges touching the specified vertex (also
     * referred to as adjacent vertices). If no edges are
     * touching the specified vertex returns an empty set.
     *
     * @param vertex the vertex for which a set of touching edges is to be
     * returned.
     *
     * @return a set of all edges touching the specified vertex.
     *
     * @throws IllegalArgumentException if vertex is not found in the graph.
     * @throws NullPointerException if vertex is null.
     */
	@Override
	public HashSet<Road> edgesOf(Town vertex) {
		//System.out.println("edgesOf");
		HashSet<Road> edges = new HashSet<Road>(vertex.getRoadList());
		return edges;
	}

	/**
     * Removes an edge going from source vertex to target vertex, if such
     * vertices and such edge exist in this graph. 
     * 
     * If weight >- 1 it must be checked
     * If description != null, it must be checked 
     * 
     * Returns the edge if removed
     * or null otherwise.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description of the edge
     *
     * @return The removed edge, or null if no edge removed.
     */
	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		//System.out.println("remove edge");
		boolean removed = false;
		Road toRemove = new Road(sourceVertex, destinationVertex, weight, description); //make a road that is the same as the one we are removing
		if ((sourceVertex.getNeighborList().contains(destinationVertex)) && (weight > -1) && (description != null)) { //if the road exists in the set and is a valid road...
			sourceVertex.removeRoad(toRemove, sourceVertex, destinationVertex); //remove the road from the source town's list
			destinationVertex.removeRoad(toRemove, sourceVertex, destinationVertex); //remove the road from the destination town's list
			Iterator<Road> roadsSetIterator = roadsSet.iterator(); //get an iterator for the graph's road list
			while (roadsSetIterator.hasNext() && (!removed)) { //while the road has not been removed, go through this list...
				Road road = roadsSetIterator.next(); //get the next road from the list to compare
				if (road.equals(toRemove)) { //if the road on the list equals the road we want to remove...
					roadsSetIterator.remove(); //remove it
					edgeCount--; 
					removed = true;
				}
			}
		}	
		if(removed) return toRemove;
		else return null;
	}

	/**
     * Removes the specified vertex from this graph including all its touching
     * edges if present. More formally, if the graph contains a vertex 
     * u such that u.equals(v), the call removes all edges
     * that touch u and then removes u itself. If no
     * such u is found, the call leaves the graph unchanged.
     * Returns true if the graph contained the specified vertex. (The
     * graph will not contain the specified vertex once the call returns).
     *
     * If the specified vertex is null returns false.
     *
     * @param v vertex to be removed from this graph, if present.
     *
     * @return true if the graph contained the specified vertex;
     * false otherwise.
     */
	@Override
	public boolean removeVertex(Town v) {
		//System.out.println("remove vertex");
		boolean contains = false;
		if (v == null) return false;
		if (this.containsVertex(v)) { //if the town exists in this graph...
			contains = true;
			Iterator<Road> roads = v.getRoadList().iterator(); //create an iterator to go through the town we are removing's roads
			while (roads.hasNext()) { //while there are roads in the list
				Road road = roads.next(); //get the next road
				removeEdge(v, road.getDestination(), road.getWeight(), road.getName()); //remove that road from the graph(and other towns?)
				removeEdge(road.getDestination(), v, road.getWeight(), road.getName());
				removeEdge(road.getSource(), v, road.getWeight(), road.getName());
				removeEdge(v, road.getSource(), road.getWeight(), road.getName());
			}
			Iterator<Town> neighbors = v.getNeighborList().iterator(); //create an iterator to go through the town's neighbors
			while (neighbors.hasNext()) { //while there are neighbors in the list
				Town neighbor = neighbors.next(); //get the next neighbor
				neighbor.removeNeighbor(v); //remove the town from that neighbor's neighbor list
			}
			townsSet.remove(v); //remove the town from this graph's list of towns
			towns.remove(v.getName(), v);  //remove the town from this graph
		}
		return contains;
	}

	/**
     * Returns a set of the vertices contained in this graph. The set is backed
     * by the graph, so changes to the graph are reflected in the set. If the
     * graph is modified while an iteration over the set is in progress, the
     * results of the iteration are undefined.
     *
     *
     * @return a set view of the vertices contained in this graph.
     */
	@Override
	public HashSet<Town> vertexSet() {
		//System.out.println("vertexSet");
		HashSet<Town> townsSet2 = new HashSet<Town>(towns.values());
		return townsSet2;
	}

	/**
     * Find the shortest path from the sourceVertex to the destinationVertex
     * call the dijkstraShortestPath with the sourceVertex
     * @param sourceVertex starting vertex
     * @param destinationVertex ending vertex
     * @return An arraylist of Strings that describe the path from sourceVertex
     * to destinationVertex
     * They will be in the format: startVertex "via" Edge "to" endVertex weight
	 * As an example: if finding path from Vertex_1 to Vertex_10, the ArrayList<String>
	 * would be in the following format(this is a hypothetical solution):
	 * Vertex_1 via Edge_2 to Vertex_3 4 (first string in ArrayList)
	 * Vertex_3 via Edge_5 to Vertex_8 2 (second string in ArrayList)
	 * Vertex_8 via Edge_9 to Vertex_10 2 (third string in ArrayList)
     */ 
	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		//System.out.println("shortestPath");
		LinkedList<Town> path = new LinkedList<Town>();
		ArrayList<String> arrayList = new ArrayList<String>();
		
		dijkstraShortestPath(sourceVertex);
		path = getPath(destinationVertex);
		if (path != null ) {
			for (int i = 0; i < path.size() - 1; i++) {
				Road road = getEdge(path.get(i), path.get(i+1));
				arrayList.add(path.get(i).toString() + " via " + road + " to " + path.get(i+1) + " " + road.getWeight() + " ");
			}
			return arrayList;
		}
		else return null;
		

	}

	/**
     * Dijkstra's Shortest Path Method.  Internal structures are built which
     * hold the ability to retrieve the path, shortest distance from the
     * sourceVertex to all the other vertices in the graph, etc.
     * @param sourceVertex the vertex to find shortest path from
     * 
     */
	@Override
	public void dijkstraShortestPath(Town sourceVertex) {
		//System.out.println("dijkstraShortestPath");
		settledNodes = new HashSet<Town>();
		unSettledNodes = new HashSet<Town>();
		distance = new HashMap<Town, Integer>();
		predecessors = new HashMap<Town, Town>();
		
		distance.put(sourceVertex, 0); //put the start town in with 0 distance
		unSettledNodes.add(sourceVertex); //put the start town in the unsettled nodes set
		
		while (unSettledNodes.size() > 0) { //while there are still nodes to be visited
			Town node = getMinimum(unSettledNodes); //get the minimum path to the next unvisited town
			settledNodes.add(node);
			unSettledNodes.remove(node);
			findMinimalDistances(node); //here more nodes are added to the unSettledNodes HashSet
		}
	}
	
	public LinkedList<Town> getPath(Town target) {
		//System.out.println("townGraph getPath");
		LinkedList<Town> path = new LinkedList<Town>();
		Town step = target;
		if (predecessors.get(step) == null) { //check if there is a path
			return null;
		}
		path.add(step);
		while (predecessors.get(step) != null) {
			step = predecessors.get(step);
			path.add(step);
		}
		Collections.reverse(path);
		//System.out.println(path.toString());
		return path;
	}
	
	
	
	private Town getMinimum(Set<Town> townSet) {
		//System.out.println("townGraph getMinimum");
		Town minimum = null;
		for (Town town : townSet) {
			if (minimum == null) minimum = town;
			else {
				if (getShortestDistance(town) < getShortestDistance(minimum)) minimum = town;
			}
		}
		return minimum;
	}
	
	public int getDistance(Town node, Town target) {
		//System.out.println("townGraph getDistance");
		for (Road road : roadsSet) {
			if (((road.getSource().equals(node)) && (road.getDestination().equals(target))) || ((road.getDestination().equals(node)) && (road.getSource().equals(target)))) {
				return road.getWeight();
			}
		}
		return Integer.MAX_VALUE;
	}
	
	public int getTotalDistaince(Town node, Town target) {
		return totalDistance;
	}
	
	private void findMinimalDistances(Town node) {
		//System.out.println("townGraph findMinimalDistances");
		List<Town> adjacentTowns = node.getNeighborList(); //returns a linked list of adjacent towns
		for (Town target : adjacentTowns) {
			if (getShortestDistance(target) > getShortestDistance(node) + getDistance(node, target)) {
				distance.put(target, getShortestDistance(node) + getDistance(node, target));
				predecessors.put(target, node);
				unSettledNodes.add(target);
			}
		}
	}
	
	private int getShortestDistance(Town destination) {
		//System.out.println("townGraph getShortestDistance");
		Integer d = distance.get(destination); 
		if (d == null)  return Integer.MAX_VALUE; 
		else return d;
	}

}
