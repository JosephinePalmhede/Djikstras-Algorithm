
public class Road implements Comparable<Road> {
	Town source, destination;
	int weight; 
	String name;
	
	public Road(Town rSource, Town rDestination, int length, String rName) {
		source = rSource;
		destination = rDestination;
		weight = length;
		name = rName;
	}
	
	public Road(Town rSource, Town rDestination, String rName) {
		source = rSource;
		destination = rDestination;
		weight = 1;
		name = rName;
	}
	
	public Road(Road copy) {
		source = copy.getSource();
		destination = copy.getDestination();
		weight = copy.getWeight();
		name = copy.getName();
	}
	
	public boolean contains(Town town) {
		if(source.equals(town) || destination.equals(town)) return true;
		else return false;
	}
	
	@Override
	public String toString() {
		return name;
	}
	
	public String getName() {
		return name;
	}
	
	public Town getDestination() {
		return destination;
	}
	
	public Town getSource() {
		return source;
	}
	
	@Override
	public int compareTo(Road r) {
		boolean equal = r.getName().equalsIgnoreCase(name);
		if (equal) return 0;
		else return -1;
	}
	
	public int getWeight() {
		return weight;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (!(o instanceof Road)) return false;
		Road r = (Road) o;
		if(source.equals(r.getSource()) && destination.equals(r.getDestination())) return true;
		else if(destination.equals(r.getSource()) && source.equals(r.getDestination())) return true;
		else return false;		
		}
	}


