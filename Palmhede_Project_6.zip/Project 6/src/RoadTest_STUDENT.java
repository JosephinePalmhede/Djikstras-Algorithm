import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RoadTest_STUDENT {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testContains() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Town town3 = new Town("town3");
		Road road = new Road(town1, town2, 2, "road1");
		assertEquals(true, road.contains(town1));
		assertEquals(true, road.contains(town2));
		assertEquals(false, road.contains(town3));
	}
	
	@Test
	public void testGetWeight() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road = new Road(town1, town2, 2, "road1");
		assertEquals(true, (road.getWeight() == 2));
	}
	
	@Test
	public void testGetName() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road = new Road(town1, town2, 2, "road1");
		assertEquals(true, (road.getName() == "road1"));
	}
	
	@Test
	public void testGetSource() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road = new Road(town1, town2, 2, "road1");
		assertEquals(true, (road.getSource().equals(town1)));
	}
	
	@Test
	public void testGetDestination() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road = new Road(town1, town2, 2, "road1");
		assertEquals(true, (road.getDestination().equals(town2)));
	}

}
