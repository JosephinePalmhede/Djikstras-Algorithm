import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class Town implements Comparable<Town>{
	private String name;
	private LinkedList<Road> roads;
	private LinkedList<Town> towns;

	private boolean visited;
	private int cost;
	
	
	public Town(String tName) {
		//System.out.println("town constructor");
		name = tName;
		visited = false;
		towns = new LinkedList<Town>();
		roads = new LinkedList<Road>();
	}
	
	public Town(Town templateTown) {
		//System.out.println("town copy constructor");
		name = templateTown.getName();
		visited = false;
		towns = templateTown.getNeighborList();
		roads = templateTown.getRoadList();
	}
	
	public String getName() {
		return name;
	}
	
	public void setCost(int c) {
		cost = c;
	}
	
	public int getCost() {
		return cost;
	}
	
	public void visit() {
		visited = true;
	}
	
	public void unvisit() {
		visited = false;
	}
	
	public boolean isVisited() {
		return visited;
	}
	
	public boolean connect(Town town, int weight, String name) {	
		//System.out.println("town connect");
		if (!towns.contains(town)) {
			Road road = new Road(this, town, weight, name); 
			if (!(roads.contains(road))) 
				roads.add(road);
			town.addRoad(road);
			addNeighbor(town); 
			return true;
		}
		else return false;
	}
	
	public LinkedList<Town> getNeighborList() {
		return towns;
	}
	
	public LinkedList<Road> getRoadList() {
		return roads;
	}
	
	public boolean removeRoad(Road road, Town source, Town destination) {
		//System.out.println("town removeRoad");
		boolean removed = false;
		if ((road.getSource().equals(this)) || road.getDestination().equals(this)) { //if this town is connected by the road...
			if ((source.equals(this))) { //if this is the road's source...
				this.removeNeighbor(destination); //remove the road destination from this town's neighbors list
				road.getDestination().removeNeighbor(this); //remove this town from the destination neighbor list
			}
			if ((destination.equals(this))) { //if this is the road's destination
				this.removeNeighbor(source); //remove the source from this town's neighbors list
				road.getSource().removeNeighbor(this); //remove this town from the source's neighbor list
			}
			roads.remove(road); //remove the road from this town's road list
			removed = true;
		}
		return removed;
	}
	
	public void removeNeighbor(Town town) {
		towns.remove(town); //remove the town from the list of neighbors
	}
	public void addNeighbor(Town town) {
		towns.add(town);
		if (towns.contains(town)) {
			town.addTown(this);
		}
	}
	
	public void addRoad(Road road) {
		roads.add(road);
	}
	
	public void addTown(Town town) {
		towns.add(town);
	}
	
	public boolean hasNeighbor() {
		return (!towns.isEmpty());
	}
	public Town getUnvisitedNeighbor() {
		Town result = null;
		while (hasNeighbor()) {
			for (int i = 0; i < towns.size(); i++) {
				if (towns.get(i).isVisited()) {
					result = towns.get(i);
					towns.get(i).visit();
				}
			}
		}
		return result;
	}

	@Override
	public int compareTo(Town arg0) {
		boolean equal = arg0.getName().equalsIgnoreCase(name);
		if (equal) return 0;
		else return -1;
	}
	
	@Override
	public String toString() {
		return name;
	}
	
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (!(o instanceof Town)) return false;
		Town r = (Town) o;
		return r.getName().equalsIgnoreCase(name);
	}

}
