import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

public class TownGraphManager implements TownGraphManagerInterface {
	private TownGraph graph;
	
	public TownGraphManager() {
		graph = new TownGraph();
	}
	/**
	 * Adds a road with 2 towns and a road name
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName name of road
	 * @return true if the road was added successfully
	 */
	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {	
		//System.out.println("TownGraphManager addRoad");
		boolean added = false;
		Town townS = graph.getTown(town1); //make town1 with the name
		Town townE = graph.getTown(town2); //make town2 with the name
		if ((graph.containsVertex(townS)) && (graph.containsVertex(townE))) { //if the graph has the two towns...
			graph.addEdge(townS, townE, weight, roadName); //add the road between the towns
			added = true;
		}
		//System.out.println(graph.edgeSet());
		return added;
	}

	/**
	 * Returns the name of the road that both towns are connected through
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return name of road if town 1 and town2 are in the same road, returns null if not
	 */
	@Override
	public String getRoad(String town1, String town2) {
		//System.out.println("TownGraphManager getRoad");
		Town townS = graph.getTown(town1);
		Town townE = graph.getTown(town2);
		//System.out.println(townS.getName() + townE.getName());
		//if (graph.getEdge(townS, townE) == null) 
		//	System.out.println("null");
		//System.out.println(road.getName());
		return graph.getEdge(townS, townE).getName();
	}

	/**
	 * Adds a town to the graph
	 * @param v the town's name  (lastname, firstname)
	 * @return true if the town was successfully added, false if not
	 */
	@Override
	public boolean addTown(String v) {
		//System.out.println("TownGraphManager addTown");
		if (v == null) return false;
		Town town = new Town(v);
		if (graph.containsVertex(town)) return false;
		else graph.addVertex(town);
		//System.out.println(graph.vertexSet());
		return true;
	}

	/**
	 * Gets a town with a given name
	 * @param name the town's name 
	 * @return the Town specified by the name, or null if town does not exist
	 */
	@Override
	public Town getTown(String name) {
		//System.out.println("TownGraphManager getTown");
		if (name != null)
			return graph.getTown(name);
		else return null;
	}

	/**
	 * Determines if a town is already in the graph
	 * @param v the town's name 
	 * @return true if the town is in the graph, false if not
	 */
	@Override
	public boolean containsTown(String v) {
		//System.out.println("TownGraphManager containsTown");
		boolean contains = false;
		Town town = graph.getTown(v);
		contains = graph.containsVertex(town);
		return contains;
	}

	/**
	 * Determines if a road is in the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return true if the road is in the graph, false if not
	 */
	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		//System.out.println("TownGraphManager containsRoadConnection");
		Town townA = graph.getTown(town1);
		Town townB = graph.getTown(town2);
		return graph.containsEdge(townA, townB);
	}

	/**
	 * Creates an arraylist of all road titles in sorted order by road name
	 * @return an arraylist of all road titles in sorted order by road name
	 */
	@Override
	public ArrayList<String> allRoads() {
		//System.out.println("TownGraphManager allRoads");
		ArrayList<String> allRoads = new ArrayList<String>();
		HashSet<Road> roads = graph.edgeSet();
		Iterator<Road> iterator = roads.iterator();
		
		while (iterator.hasNext()) {
			allRoads.add(iterator.next().getName());
		}
		
		Collections.sort(allRoads);	
		return allRoads;
	}

	/**
	 * Deletes a road from the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName the road name
	 * @return true if the road was successfully deleted, false if not
	 */
	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		//System.out.println("TownGraphManager deleteRoadConnection");
		Town townA = graph.getTown(town1);
		Town townB = graph.getTown(town2);
		Road roadA = graph.getEdge(townA, townB);
		Road removed = graph.removeEdge(townA, townB, roadA.getWeight(), road);
		if (removed == null) return false;
		else return true;
	}

	/**
	 * Deletes a town from the graph
	 * @param v name of town (lastname, firstname)
	 * @return true if the town was successfully deleted, false if not
	 */
	@Override
	public boolean deleteTown(String v) {
		//System.out.println("TownGraphManager deleteTown");
		Town town = graph.getTown(v);
		return graph.removeVertex(town);
	}

	/**
	 * Creates an arraylist of all towns in alphabetical order (last name, first name)
	 * @return an arraylist of all towns in alphabetical order (last name, first name)
	 */
	@Override
	public ArrayList<String> allTowns() {
		//System.out.println("TownGraphManager allTowns");
		ArrayList<String> allTowns = new ArrayList<String>(); //create arraylist to hold the strings of town names
		HashSet<Town> towns = graph.vertexSet(); //create a hash set that contains the set of towns in the graph
		Iterator<Town> iterator = towns.iterator(); //create an iterator to go through hashset
		
		while (iterator.hasNext()) { //iterate through the hashSet of towns
			String name = iterator.next().getName();
			if (!allTowns.contains(name)) allTowns.add(name);
		}
		
		Collections.sort(allTowns);	
		return allTowns;
	}

	/**
	 * Returns the shortest path from town 1 to town 2
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return an Arraylist of roads connecting the two towns together, null if the
	 * towns have no path to connect them.
	 */
	@Override
	public ArrayList<String> getPathSets(String town1, String town2) {
		//System.out.println("TownGraphManager getPathSets");
		return graph.shortestPath(getTown(town1), getTown(town2));
	}

	/**
	 * Returns the shortest path from town 1 to town 2
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return an Arraylist of roads connecting the two towns together, null if the
	 * towns have no path to connect them.
	 */
	public ArrayList<String> getPath(String name, String name2) {
		//System.out.println("TownGraphManager getPath");
		ArrayList<String> path = graph.shortestPath(getTown(name), getTown(name2));
		StringTokenizer tokens;
		int totalDistance = 0;
		if (path != null) {
			for (int i = 0; i < path.size(); i++) {
				path.set(i, path.get(i) + "miles");
				tokens = new StringTokenizer(path.get(i), " ");
				tokens.nextToken();
				tokens.nextToken();
				tokens.nextToken();
				tokens.nextToken();
				tokens.nextToken();
				totalDistance += Integer.parseInt(tokens.nextToken());
			}
			path.add("Total miles: " + totalDistance + " miles");
			return path;
		}
		else return null;
	}

	//from the GUI
	public void populateTownGraph(File selectedFile) throws FileNotFoundException {
		//System.out.println("TownGraphManager populateTownGraph");

		String line, roadName, startName, endName;
		int distance;
		String[] splitLine;
		String[] splitRoad;
		
		try {
			Scanner inputFile = new Scanner(selectedFile);
			while (inputFile.hasNextLine()) {
				line = inputFile.nextLine(); 
				splitLine = line.split(";");
				startName = splitLine[1];
				endName = splitLine[2];
				splitRoad = splitLine[0].split(",");
				roadName = splitRoad[0];
				distance = Integer.parseInt(splitRoad[1]);

				addTown(startName);
				addTown(endName);
				addRoad(startName, endName, distance, roadName);
				
			}
			inputFile.close();
		} catch (IOException e) {
			e.getStackTrace();
		} 
		
	}

}
