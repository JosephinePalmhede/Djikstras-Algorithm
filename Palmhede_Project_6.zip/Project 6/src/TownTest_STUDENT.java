import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TownTest_STUDENT {

	@Before
	public void setUp() throws Exception {

	}
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConnect() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road1 = new Road(town1, town2, 2, "road1");
		assertEquals(true, town1.connect(town2, 2, "road1"));
		assertEquals(true, (town1.getRoadList().contains(road1)));
		assertEquals(true, (town2.getRoadList().contains(road1)));
	}
	
	@Test
	public void testAddRoad() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road1 = new Road(town1, town2, 2, "road1");
		town1.addRoad(road1);
		town1.connect(town2, 2, "road1");
		assertEquals(true, (town1.getRoadList().contains(road1)));
		assertEquals(false, (town1.getRoadList().size() > 1));
		assertEquals(true, (town2.getRoadList().contains(road1)));
	}
	
	@Test
	public void testremoveRoad() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road road1 = new Road(town1, town2, 2, "road1");
		town1.addRoad(road1);
		town1.connect(town2, 2, "road1");
		assertEquals(true, (town1.getRoadList().contains(road1)));
		assertEquals(false, (town1.getRoadList().size() > 1));
		assertEquals(true, (town2.getRoadList().contains(road1)));
		town1.removeRoad(road1, town2, town1);
		assertEquals(false, (town1.getRoadList().contains(road1)));
		assertEquals(true, (town1.getRoadList().size() == 0));
	}
}
