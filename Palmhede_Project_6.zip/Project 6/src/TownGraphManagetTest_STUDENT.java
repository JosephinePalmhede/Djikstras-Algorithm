import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TownGraphManagetTest_STUDENT {
	private TownGraphManagerInterface graph;
	private String[] town;
	  
	@Before
	public void setUp() throws Exception {
		  graph = new TownGraphManager();
		  town = new String[12];
		  
		  for (int i = 1; i < 12; i++) {
			  town[i] = "Town" + i;
			  graph.addTown(town[i]);
		  }
		  
		  graph.addRoad(town[1], town[2], 3, "Road1");
		  graph.addRoad(town[1], town[3], 5, "Road2");
		  graph.addRoad(town[1], town[5], 7, "Road3");
		  graph.addRoad(town[3], town[7], 2, "Road4");
		  graph.addRoad(town[3], town[8], 3, "Road5");
		  graph.addRoad(town[4], town[8], 4, "Road6");
		  graph.addRoad(town[6], town[9], 4, "Road7");
		  graph.addRoad(town[9], town[10], 5, "Road8");
		  graph.addRoad(town[8], town[10], 3, "Road9");
		  graph.addRoad(town[5], town[10], 6, "Road10");
		  graph.addRoad(town[10], town[11], 4, "Road11");
		  graph.addRoad(town[2], town[11], 7, "Road12");
		 
	}

	@After
	public void tearDown() throws Exception {
		graph = null;
	}

	@Test
	public void testAddRoad() {
		ArrayList<String> roads = graph.allRoads();
		assertEquals("Road1", roads.get(0));
		assertEquals("Road10", roads.get(1));
		assertEquals("Road11", roads.get(2));
		assertEquals("Road12", roads.get(3));
		graph.addRoad(town[4], town[11], 1,"Road13");
		roads = graph.allRoads();
		assertEquals("Road1", roads.get(0));
		assertEquals("Road10", roads.get(1));
		assertEquals("Road11", roads.get(2));
		assertEquals("Road12", roads.get(3));
		assertEquals("Road13", roads.get(4));
		
	}

	@Test
	public void testGetRoad() {
		assertEquals("Road12", graph.getRoad(town[2], town[11]));
		assertEquals("Road4", graph.getRoad(town[3], town[7]));
	}

	@Test
	public void testAddTown() {
		assertEquals(false, graph.containsTown("Town12"));
		graph.addTown("Town12");
		assertEquals(true, graph.containsTown("Town12"));
	}

	@Test
	public void testContainsTown() {
		assertEquals(true, graph.containsTown("Town2"));
		assertEquals(false, graph.containsTown("Town12"));
	}

	@Test
	public void testContainsRoadConnection() {
		assertEquals(true, graph.containsRoadConnection(town[2], town[11]));
		assertEquals(false, graph.containsRoadConnection(town[3], town[5]));
	}

	@Test
	public void testAllRoads() {
		ArrayList<String> roads = graph.allRoads();
		assertEquals("Road1", roads.get(0));
		assertEquals("Road10", roads.get(1));
		assertEquals("Road11", roads.get(2));
		assertEquals("Road8", roads.get(10));
		assertEquals("Road9", roads.get(11));
	}

	@Test
	public void testDeleteRoadConnection() {
		assertEquals(true, graph.containsRoadConnection(town[2], town[11]));
		graph.deleteRoadConnection(town[2], town[11], "Road12");
		assertEquals(false, graph.containsRoadConnection(town[2], town[11]));
	}

	@Test
	public void testDeleteTown() {
		assertEquals(true, graph.containsTown("Town2"));
		graph.deleteTown(town[2]);
		assertEquals(false, graph.containsTown("Town2"));
	}

	
	@Test
	public void testAllTowns() {
		ArrayList<String> roads = graph.allTowns();
		assertEquals("Town1", roads.get(0));
		assertEquals("Town10", roads.get(1));
		assertEquals("Town11", roads.get(2));
		assertEquals("Town2", roads.get(3));
		assertEquals("Town8", roads.get(9));
	}

	@Test
	public void testGetPath() {
		ArrayList<String> path = graph.getPath(town[1],town[11]);
		  assertNotNull(path);
		  assertTrue(path.size() > 0);
		  assertEquals("Town1 via Road1 to Town2 3 miles",path.get(0).trim());
		  assertEquals("Town2 via Road12 to Town11 7 miles",path.get(1).trim());
		  assertEquals("Total miles: 10 miles",path.get(2).trim());

	}
	
	@Test
	public void testGetPathA() {
		ArrayList<String> path = graph.getPath(town[1],town[10]);
		  assertNotNull(path);
		  assertTrue(path.size() > 0);
		  assertEquals("Town1 via Road2 to Town3 5 miles",path.get(0).trim());
		  assertEquals("Town3 via Road5 to Town8 3 miles",path.get(1).trim());
		  assertEquals("Town8 via Road9 to Town10 3 miles",path.get(2).trim());
		  assertEquals("Total miles: 11 miles",path.get(3).trim());
	}
	
	@Test
	public void testGetPathB() {
		ArrayList<String> path = graph.getPath(town[1],town[6]);
		  assertNotNull(path);
		  assertTrue(path.size() > 0);
		  assertEquals("Town1 via Road2 to Town3 5 miles",path.get(0).trim());
		  assertEquals("Town3 via Road5 to Town8 3 miles",path.get(1).trim());
		  assertEquals("Town8 via Road9 to Town10 3 miles",path.get(2).trim());
		  assertEquals("Town10 via Road8 to Town9 5 miles",path.get(3).trim());
		  assertEquals("Town9 via Road7 to Town6 4 miles",path.get(4).trim());
		  assertEquals("Total miles: 20 miles",path.get(5).trim());

	}
}